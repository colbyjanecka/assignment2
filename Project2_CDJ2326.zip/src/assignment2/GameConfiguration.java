/* EE422C Assignment #2 submission by
 * Colby Janecka
 * CDJ2326
 */

package assignment2;

class GameConfiguration {
	static final int guessNumber = 12;
	static final String[] colors = {"B","G","O","P","R","Y"};
	static final int pegNumber = 4;
}
